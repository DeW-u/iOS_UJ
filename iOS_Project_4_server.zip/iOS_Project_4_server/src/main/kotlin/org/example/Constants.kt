package org.example

object Constants {

    const val PORT = 8010
}
package org.example.plugins

import io.ktor.server.application.*
import org.example.routes.routes_categories.configureItemsRoutes

fun Application.configureRouting() {
    configureItemsRoutes()
}

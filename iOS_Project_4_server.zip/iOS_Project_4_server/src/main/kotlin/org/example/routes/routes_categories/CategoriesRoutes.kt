package org.example.routes.routes_categories

import io.ktor.http.*
import io.ktor.server.application.*
import io.ktor.server.response.*
import io.ktor.server.routing.*
import org.example.data.MockData

fun Application.configureItemsRoutes() {

    routing {
        getItemsRoute()
    }
}

private fun Route.getItemsRoute() {
    get("/api/categories") {
        call.respond(
            HttpStatusCode.OK,
            MockData.generateCategoriesExample()
        )
    }
}
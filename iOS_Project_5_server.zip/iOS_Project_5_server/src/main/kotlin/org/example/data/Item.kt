package org.example.data

import kotlinx.serialization.Serializable

@Serializable
data class Item(
    val name: String,
    val desc: String,
    val price: Double
)

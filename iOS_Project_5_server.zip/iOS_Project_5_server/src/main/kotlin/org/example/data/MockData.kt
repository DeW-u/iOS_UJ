package org.example.data

object MockData {
    val listOfUsers: MutableList<UserAuthRequest> = mutableListOf()

    fun generateCategoriesExample(): List<Category> {
        val listOfCategories = mutableListOf<Category>()

        val meatCategory = Category(
            name = "Meats",
            items = generateItemsExample().filter { it.name.contains("Chicken") }
        )

        val dairyCategory = Category(
            name = "Dairy",
            items = generateItemsExample().filter { it.name.contains("Milk") }
        )

        val sweetsCategory = Category(
            name = "Sweets",
            items = generateItemsExample().filter { it.name.contains("Candy") }
        )

        listOfCategories.add(meatCategory)
        listOfCategories.add(dairyCategory)
        listOfCategories.add(sweetsCategory)

        return listOfCategories
    }

    private fun generateItemsExample(): List<Item> {
        val listOfItems = mutableListOf<Item>()

        for (index in 1..3) {
            val newMeatItem = Item(
                name = "Chicken #${index}",
                desc = "It's chicken no. ${index}",
                price = index.toDouble() + 9.99
            )

            val newDairyItem = Item(
                name = "Milk #${index}",
                desc = "It's milk no. ${index}",
                price = index.toDouble() + 4.99
            )

            val newSweetsItem = Item(
                name = "Candy #${index}",
                desc = "It's candy no. ${index}",
                price = index.toDouble() + 0.99
            )

            listOfItems.add(newMeatItem)
            listOfItems.add(newDairyItem)
            listOfItems.add(newSweetsItem)
        }

        return listOfItems
    }
}
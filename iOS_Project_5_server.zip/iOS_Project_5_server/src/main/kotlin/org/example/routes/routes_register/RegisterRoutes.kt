package org.example.routes.routes_register

import io.ktor.http.*
import io.ktor.server.application.*
import io.ktor.server.request.*
import io.ktor.server.response.*
import io.ktor.server.routing.*
import org.example.data.MockData
import org.example.data.UserAuthRequest

fun Application.configureRegisterRoute() {

    routing {
        postRegisterRoute()
    }
}

private fun Route.postRegisterRoute() {
    post("/api/register") {
        val request = call.receiveNullable<UserAuthRequest>() ?: run {
            call.respond(
                HttpStatusCode.BadRequest,
                "Be sure you passed username, password and group parameters."
            )
            return@post
        }

        if (request.username.isBlank() || request.password.isBlank()) {
            call.respond(
                HttpStatusCode.BadRequest,
                "Username and password can't be blank."
            )

            return@post
        }

        MockData.listOfUsers.add(request)

        call.respond(
            HttpStatusCode.OK,
            "User successfully registered."
        )

        return@post
    }
}
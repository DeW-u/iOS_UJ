package org.example.routes.routes_login

import io.ktor.http.*
import io.ktor.server.application.*
import io.ktor.server.request.*
import io.ktor.server.response.*
import io.ktor.server.routing.*
import org.example.data.MockData
import org.example.data.UserAuthRequest

fun Application.configureLoginRoute() {

    routing {
        postLoginRoute()
    }
}

private fun Route.postLoginRoute() {
    post("/api/login") {
        val request = call.receiveNullable<UserAuthRequest>() ?: run {
            call.respond(
                HttpStatusCode.BadRequest,
                "Username and password can't be blank"
            )
            return@post
        }

        if (request.username.isBlank() || request.password.isBlank()) {
            call.respond(
                HttpStatusCode.BadRequest,
                "Username and password can't be blank."
            )

            return@post
        }

        if (MockData.listOfUsers.contains(request).not()) {
            call.respond(
                HttpStatusCode.BadRequest,
                "User not found"
            )

            return@post
        }

        MockData.listOfUsers.add(request)

        call.respond(
            HttpStatusCode.OK,
            "Login successful."
        )

        return@post
    }
}
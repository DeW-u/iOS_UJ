package org.example.org.example

import io.ktor.server.engine.*
import io.ktor.server.netty.*
import org.example.Constants
import org.example.plugins.configureKoin
import org.example.plugins.configureMonitoring
import org.example.plugins.configureRouting
import org.example.plugins.configureSerialization

fun main() {
    embeddedServer(Netty, port = Constants.PORT) {
        configureKoin()
        configureSerialization()
        configureMonitoring()
        configureRouting()
    }.start(true)
}
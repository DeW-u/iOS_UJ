package org.example.plugins

import io.ktor.server.application.*
import org.example.routes.routes_categories.configureItemsRoutes
import org.example.routes.routes_login.configureLoginRoute
import org.example.routes.routes_payment.configureCardPaymentRoute
import org.example.routes.routes_register.configureRegisterRoute

fun Application.configureRouting() {
    configureItemsRoutes()
    configureRegisterRoute()
    configureLoginRoute()
    configureCardPaymentRoute()
}

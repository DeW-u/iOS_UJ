package org.example.di


import org.koin.dsl.module
import kotlin.io.encoding.ExperimentalEncodingApi

@OptIn(ExperimentalEncodingApi::class)
val dataModule = module {

}
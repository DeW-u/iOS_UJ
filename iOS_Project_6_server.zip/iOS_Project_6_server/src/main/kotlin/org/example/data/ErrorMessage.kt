package org.example.data

import kotlinx.serialization.Serializable

@Serializable
data class ErrorMessage(
    val error: String
)

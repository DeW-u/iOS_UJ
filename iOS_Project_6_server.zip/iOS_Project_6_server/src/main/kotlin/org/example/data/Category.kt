package org.example.data

import kotlinx.serialization.Serializable

@Serializable
data class Category(
    val name: String,
    val items: List<Item>
)

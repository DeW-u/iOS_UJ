package org.example.data

import kotlinx.serialization.Serializable

@Serializable
data class UserAuthRequest (
    val username: String,
    val password: String
)

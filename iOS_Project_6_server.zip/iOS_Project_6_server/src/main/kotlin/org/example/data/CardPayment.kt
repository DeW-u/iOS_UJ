package org.example.data

import kotlinx.serialization.Serializable
import org.joda.time.DateTime

@Serializable
data class CardPayment(
    val cardNumber: String,
    val expirationDate: String,
    val cvvCode: String,
    val ownerFirstName: String,
    val ownerLastName: String
)

fun CardPayment.validate(): Pair<Boolean, String?> {
    try {
        val correctCardNumber = cardNumber.replace(" ", "").toDouble()
    } catch (ex: Exception) {
        return false to "Incorrect credit card number"
    }

    val expirationDateRegex = Regex("""(0[1-9]|10|11|12)/[0-9]{2}${'$'}""")

    if (expirationDateRegex.matches(expirationDate).not()) return false to "Invalid expiration date"

    if (cvvCode.count() != 3) return false to "Invalid CVV code"

    try {
        val correctCvvCode = cvvCode.toInt()
    } catch (ex: Exception) {
        return false to "Invalid CVV code"
    }

    return true to null
}
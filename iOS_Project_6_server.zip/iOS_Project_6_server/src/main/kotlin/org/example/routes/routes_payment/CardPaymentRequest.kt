package org.example.routes.routes_payment

import io.ktor.http.*
import io.ktor.server.application.*
import io.ktor.server.request.*
import io.ktor.server.response.*
import io.ktor.server.routing.*
import org.example.data.CardPayment
import org.example.data.ErrorMessage
import org.example.data.validate

fun Application.configureCardPaymentRoute() {

    routing {
        postCardPaymentRoute()
    }
}

private fun Route.postCardPaymentRoute() {
    post("/api/cardPayment") {
        val request = call.receiveNullable<CardPayment>() ?: run {
            call.respond(
                HttpStatusCode.BadRequest,
                ErrorMessage("Invalid credit card credentials")
            )
            return@post
        }

        val requestValidationResult = request.validate()

        if (requestValidationResult.first.not()) {
            call.respond(
                HttpStatusCode.BadRequest,
                ErrorMessage(requestValidationResult.second ?: "Unknown error")
            )

            return@post
        }

        call.respond(
            HttpStatusCode.OK,
            "Payment completed successfully"
        )

        return@post
    }
}